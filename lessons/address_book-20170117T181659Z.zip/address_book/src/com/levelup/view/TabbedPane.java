package com.levelup.view;

import javax.swing.*;
import java.util.List;

/**
 * Created by Алексей on 11.01.2017.
 */
public class TabbedPane extends JTabbedPane implements Action {

    @Override
    public void create() {

    }

    @Override
    public List read() {
        return null;
    }

    @Override
    public void update() {

    }

    @Override
    public void delete() {

    }
}
